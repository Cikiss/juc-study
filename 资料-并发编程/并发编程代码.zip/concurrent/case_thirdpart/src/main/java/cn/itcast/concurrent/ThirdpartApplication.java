package cn.itcast.concurrent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThirdpartApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThirdpartApplication.class, args);
    }

}
